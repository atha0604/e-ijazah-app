# Aplikasi Nilai E-Ijazah (Native Version)

## Cara Instalasi dan Penggunaan

### 1. Instalasi Dependencies
Double-click file: `INSTALL.bat`

Atau manual via command prompt:
```
npm install
```

### 2. Menjalankan Aplikasi
Double-click file: `JALANKAN-APLIKASI.bat`

Atau manual via command prompt:
- Auto mode: `node app-native.js`
- Offline only: `node app-native.js --offline`
- Online only: `node app-native.js --online`

### 3. Mode Aplikasi

#### AUTO MODE (Recommended)
- Aplikasi akan otomatis mendeteksi koneksi internet
- Jika ada internet: menggunakan versi online (selalu update)
- Jika tidak ada internet: menggunakan versi offline (data lokal)

#### OFFLINE MODE
- Paksa menggunakan server lokal
- Data tersimpan di komputer
- Tidak memerlukan internet

#### ONLINE MODE
- Paksa menggunakan server online
- Data tersimpan di cloud
- Memerlukan koneksi internet

### 4. Akses Aplikasi
Setelah aplikasi berjalan, browser akan terbuka otomatis.
Jika tidak, buka browser dan kunjungi:
- Mode offline: http://localhost:3000
- Mode online: https://nilai-e-ijazah.koyeb.app

### 5. Kebutuhan Sistem
- Node.js 18 atau lebih baru
- NPM 9 atau lebih baru
- Browser modern (Chrome, Firefox, Edge)

### 6. Troubleshooting
- Jika port 3000 sudah digunakan, ubah PORT di file .env
- Jika ada error, coba install ulang dependencies dengan INSTALL.bat
- Untuk reset data offline, hapus file database di folder src/database/

---
Dikembangkan oleh: Prasetya Lukmana
Versi: 2.7.0
